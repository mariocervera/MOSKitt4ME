package moskitt4me.projectmanager.core.providers;

import org.eclipse.epf.uma.impl.DomainImpl;

public class UncategorizedDomain extends DomainImpl {

	public UncategorizedDomain() {
		
	}
}
