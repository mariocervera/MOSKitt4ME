package es.cv.gvcase.trmanager.ui.wizards;

import java.util.HashMap;

import es.cv.gvcase.trmanager.TransformedResource;

public interface ITransformationWizardInputResources {

	public HashMap<String, TransformedResource> getInputResources();

}
